#
# TABLE STRUCTURE FOR: barang
#

DROP TABLE IF EXISTS `barang`;

CREATE TABLE `barang` (
  `id_barang` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(128) NOT NULL,
  `kondisi` enum('baik','rusak') NOT NULL,
  `ketersedian` enum('ada','tidak') NOT NULL,
  `image` varchar(256) NOT NULL,
  PRIMARY KEY (`id_barang`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

INSERT INTO `barang` (`id_barang`, `nama`, `kondisi`, `ketersedian`, `image`) VALUES (1, 'LCD2', 'baik', 'ada', 'lcd1.jpg');
INSERT INTO `barang` (`id_barang`, `nama`, `kondisi`, `ketersedian`, `image`) VALUES (2, 'Layar Proyektor', 'baik', 'tidak', 'layar_proyektor1.jpg');
INSERT INTO `barang` (`id_barang`, `nama`, `kondisi`, `ketersedian`, `image`) VALUES (3, 'Kabel UTP', 'rusak', 'ada', 'utp.png');
INSERT INTO `barang` (`id_barang`, `nama`, `kondisi`, `ketersedian`, `image`) VALUES (4, 'Router', 'baik', 'ada', 'router.jpg');
INSERT INTO `barang` (`id_barang`, `nama`, `kondisi`, `ketersedian`, `image`) VALUES (7, 'Speaker', 'baik', 'ada', 'speker1.jpg');


#
# TABLE STRUCTURE FOR: dinas
#

DROP TABLE IF EXISTS `dinas`;

CREATE TABLE `dinas` (
  `id_dinas` int(11) NOT NULL AUTO_INCREMENT,
  `nama_dinas` varchar(128) NOT NULL,
  PRIMARY KEY (`id_dinas`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4;

INSERT INTO `dinas` (`id_dinas`, `nama_dinas`) VALUES (3, 'Dinas Komunikasi dan Informatika');
INSERT INTO `dinas` (`id_dinas`, `nama_dinas`) VALUES (4, 'Dinas Pariwisata');
INSERT INTO `dinas` (`id_dinas`, `nama_dinas`) VALUES (5, 'Dinas Lingkungan Hidup');
INSERT INTO `dinas` (`id_dinas`, `nama_dinas`) VALUES (6, 'Satpol PP');
INSERT INTO `dinas` (`id_dinas`, `nama_dinas`) VALUES (7, 'Dinas Pertanian');
INSERT INTO `dinas` (`id_dinas`, `nama_dinas`) VALUES (8, 'Dinas Kesehatan');
INSERT INTO `dinas` (`id_dinas`, `nama_dinas`) VALUES (9, 'Dinas Perhubungan');
INSERT INTO `dinas` (`id_dinas`, `nama_dinas`) VALUES (10, 'Dinas Pemadam Kebakaran');
INSERT INTO `dinas` (`id_dinas`, `nama_dinas`) VALUES (11, 'Dinas PUPR Bina Marga');
INSERT INTO `dinas` (`id_dinas`, `nama_dinas`) VALUES (14, 'Dinas Ketahanan Pangan');
INSERT INTO `dinas` (`id_dinas`, `nama_dinas`) VALUES (17, 'Dinas Pendidikan');


#
# TABLE STRUCTURE FOR: peminjaman
#

DROP TABLE IF EXISTS `peminjaman`;

CREATE TABLE `peminjaman` (
  `id_peminjaman` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `id_barang` int(11) DEFAULT NULL,
  `tgl_peminjaman` date NOT NULL,
  `tgl_kembali` date NOT NULL,
  `keterangan` text NOT NULL,
  `status_peminjaman` enum('diajukan','disetujui') NOT NULL,
  `status_pengembalian` enum('sudah','belum') NOT NULL,
  PRIMARY KEY (`id_peminjaman`),
  KEY `id_user` (`id_user`,`id_barang`),
  KEY `id_barang` (`id_barang`),
  CONSTRAINT `peminjaman_ibfk_1` FOREIGN KEY (`id_barang`) REFERENCES `barang` (`id_barang`),
  CONSTRAINT `peminjaman_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4;

INSERT INTO `peminjaman` (`id_peminjaman`, `id_user`, `id_barang`, `tgl_peminjaman`, `tgl_kembali`, `keterangan`, `status_peminjaman`, `status_pengembalian`) VALUES (1, 8, 1, '2021-01-12', '2021-01-15', 'Untuk acara penting', 'disetujui', 'belum');
INSERT INTO `peminjaman` (`id_peminjaman`, `id_user`, `id_barang`, `tgl_peminjaman`, `tgl_kembali`, `keterangan`, `status_peminjaman`, `status_pengembalian`) VALUES (2, 7, 2, '2021-01-13', '2021-01-14', 'Untuk rapat', 'disetujui', 'sudah');
INSERT INTO `peminjaman` (`id_peminjaman`, `id_user`, `id_barang`, `tgl_peminjaman`, `tgl_kembali`, `keterangan`, `status_peminjaman`, `status_pengembalian`) VALUES (3, 11, 2, '2021-01-19', '2021-01-19', 'asasas', 'disetujui', 'sudah');
INSERT INTO `peminjaman` (`id_peminjaman`, `id_user`, `id_barang`, `tgl_peminjaman`, `tgl_kembali`, `keterangan`, `status_peminjaman`, `status_pengembalian`) VALUES (5, 11, 3, '2021-01-21', '2021-01-06', '', 'disetujui', 'belum');
INSERT INTO `peminjaman` (`id_peminjaman`, `id_user`, `id_barang`, `tgl_peminjaman`, `tgl_kembali`, `keterangan`, `status_peminjaman`, `status_pengembalian`) VALUES (11, 8, 4, '2021-01-20', '2021-01-21', 'aaaa', 'diajukan', 'belum');
INSERT INTO `peminjaman` (`id_peminjaman`, `id_user`, `id_barang`, `tgl_peminjaman`, `tgl_kembali`, `keterangan`, `status_peminjaman`, `status_pengembalian`) VALUES (12, 8, 4, '2021-01-19', '2021-01-22', 'aaaaaaaaaaaaaaaaaaaaaaaaaaa', 'diajukan', 'belum');
INSERT INTO `peminjaman` (`id_peminjaman`, `id_user`, `id_barang`, `tgl_peminjaman`, `tgl_kembali`, `keterangan`, `status_peminjaman`, `status_pengembalian`) VALUES (13, 8, 2, '2021-01-15', '2021-01-22', '111', 'disetujui', 'belum');
INSERT INTO `peminjaman` (`id_peminjaman`, `id_user`, `id_barang`, `tgl_peminjaman`, `tgl_kembali`, `keterangan`, `status_peminjaman`, `status_pengembalian`) VALUES (38, 8, 3, '2021-01-22', '2021-01-23', '1111', 'diajukan', 'belum');
INSERT INTO `peminjaman` (`id_peminjaman`, `id_user`, `id_barang`, `tgl_peminjaman`, `tgl_kembali`, `keterangan`, `status_peminjaman`, `status_pengembalian`) VALUES (39, 10, 3, '2021-01-20', '2021-01-22', 'aaa', 'diajukan', 'belum');
INSERT INTO `peminjaman` (`id_peminjaman`, `id_user`, `id_barang`, `tgl_peminjaman`, `tgl_kembali`, `keterangan`, `status_peminjaman`, `status_pengembalian`) VALUES (40, 11, 3, '2021-01-18', '2021-01-28', 'sss', 'diajukan', 'belum');


#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `id_dinas` int(11) NOT NULL,
  `email` varchar(128) NOT NULL,
  `image` varchar(128) NOT NULL,
  `password` varchar(256) NOT NULL,
  `id_role` int(1) NOT NULL,
  `is_active` enum('aktif','pasif') NOT NULL,
  `date_created` int(11) NOT NULL,
  PRIMARY KEY (`id_user`),
  KEY `id_dinas` (`id_dinas`),
  KEY `id_role` (`id_role`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`id_dinas`) REFERENCES `dinas` (`id_dinas`),
  CONSTRAINT `user_ibfk_2` FOREIGN KEY (`id_role`) REFERENCES `user_role` (`id_role`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4;

INSERT INTO `user` (`id_user`, `name`, `id_dinas`, `email`, `image`, `password`, `id_role`, `is_active`, `date_created`) VALUES (4, 'Winandri Kusuma', 3, 'winandrikusuma27@gmail.com', 'petertnak1.png', '$2y$10$/e6ObGnLuSBR6X0d8ugo5Of/rRlQZj2BLCSx/vY56BF5KRSnbgWWm', 1, 'aktif', 1604837683);
INSERT INTO `user` (`id_user`, `name`, `id_dinas`, `email`, `image`, `password`, `id_role`, `is_active`, `date_created`) VALUES (7, 'coba2333c', 4, 'narutomimimi@gmail.com', 'kerbau11.png', '$2y$10$OhDGLMd/gIiZ.YWEXxPypOB68SJQQBdZ/82euoq3yWfULCwv8nniy', 2, 'aktif', 1610359846);
INSERT INTO `user` (`id_user`, `name`, `id_dinas`, `email`, `image`, `password`, `id_role`, `is_active`, `date_created`) VALUES (8, 'fandizaq', 6, 'fandi.zahiradana@gmail.com', 'avatar2.png', '$2y$10$/NST2DhalV4YLkMXPum24uvg3LupxHBfQy4qLl/N/WclToZmbmvq.', 2, 'aktif', 1610359986);
INSERT INTO `user` (`id_user`, `name`, `id_dinas`, `email`, `image`, `password`, `id_role`, `is_active`, `date_created`) VALUES (9, 'cccc', 5, 'coba2@gmail.com', 'default.png', '$2y$10$Trv2SjUQwJO85s3xpTWAlujXKCNXbVvFCG7yzIBT6aSR7JhFxuRH2', 2, 'pasif', 1610386221);
INSERT INTO `user` (`id_user`, `name`, `id_dinas`, `email`, `image`, `password`, `id_role`, `is_active`, `date_created`) VALUES (10, 'aaa', 11, 'robert@gmail.com', 'default.png', '$2y$10$4h3CQHNQwI88nabtacb79.ucp5NmiYc9q7D.ChuUgyRuEgCYhYXhW', 2, 'aktif', 1610552184);
INSERT INTO `user` (`id_user`, `name`, `id_dinas`, `email`, `image`, `password`, `id_role`, `is_active`, `date_created`) VALUES (11, 'ade chandra', 4, 'ade.cand.jr@gmail.com', 'default.png', '$2y$10$VhrHNjmsgH57ulVZSR2gpueizWYf8X7m5FGlGL.d3gKVA3l42ae82', 2, 'pasif', 1610634268);
INSERT INTO `user` (`id_user`, `name`, `id_dinas`, `email`, `image`, `password`, `id_role`, `is_active`, `date_created`) VALUES (12, 'asdas', 10, 'albabaihaki12@gmail.com', 'default.png', '$2y$10$XSbxuqk1ZoYNmmGjJC7u/.C8IQdNASxzZzdoyrPvk13GTCU.ZpJza', 2, 'pasif', 1611557711);
INSERT INTO `user` (`id_user`, `name`, `id_dinas`, `email`, `image`, `password`, `id_role`, `is_active`, `date_created`) VALUES (21, 'naufal', 17, 'naufalyudhistira12@gmail.com', 'default.png', '$2y$10$F0Rm4ax9r0Ohl0TMx.esXOkchLFX0pc.u/sw05cmKyK7x65G4Y3Te', 2, 'pasif', 1615265944);


#
# TABLE STRUCTURE FOR: user_role
#

DROP TABLE IF EXISTS `user_role`;

CREATE TABLE `user_role` (
  `id_role` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(128) NOT NULL,
  PRIMARY KEY (`id_role`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `user_role` (`id_role`, `role`) VALUES (1, 'admin');
INSERT INTO `user_role` (`id_role`, `role`) VALUES (2, 'peminjam');


#
# TABLE STRUCTURE FOR: user_token
#

DROP TABLE IF EXISTS `user_token`;

CREATE TABLE `user_token` (
  `id_token` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(128) NOT NULL,
  `token` varchar(128) NOT NULL,
  `date_created` int(11) NOT NULL,
  PRIMARY KEY (`id_token`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4;

INSERT INTO `user_token` (`id_token`, `email`, `token`, `date_created`) VALUES (1, 'narutomimimi@gmail.com', 'nXJmNztJXQyZVSFTEE3i/uFS4R3fBPw5b9gGg9bOvQc=', 1610359846);
INSERT INTO `user_token` (`id_token`, `email`, `token`, `date_created`) VALUES (2, 'fandi.zahiradana@gmail.com', 'qhT4LJ+7ypY1fWAKzxzJqUkGEGGUxVC9FyUemTMywLM=', 1610359986);
INSERT INTO `user_token` (`id_token`, `email`, `token`, `date_created`) VALUES (3, 'coba2@gmail.com', 'Ptj9+kT8V5IoMshLqIU0zayihCpiIQP3jdnYl4ia+wE=', 1610386221);
INSERT INTO `user_token` (`id_token`, `email`, `token`, `date_created`) VALUES (4, 'robert@gmail.com', 'sdFrSUIwStuMInys9qP9XLTsVJP5Z4uH1KyuPU1XYxk=', 1610552184);
INSERT INTO `user_token` (`id_token`, `email`, `token`, `date_created`) VALUES (5, 'ade.cand.jr@gmail.com', 'VYO+P+ydVmRCqd8ZF9kuZaHUpd5g78txX19smcjp8X8=', 1610634268);
INSERT INTO `user_token` (`id_token`, `email`, `token`, `date_created`) VALUES (6, 'winandrikusuma27@gmail.com', 'Q1TV7ZP9nWyfiNTZA8E9EVPY3eQeYb+o6tsNTHoS3jc=', 1610873986);
INSERT INTO `user_token` (`id_token`, `email`, `token`, `date_created`) VALUES (7, 'winandrikusuma27@gmail.com', 'J/lECwMwIJw5SJ9hBMCXO3ddaDYVkxs37kOLnBddmfw=', 1610874232);
INSERT INTO `user_token` (`id_token`, `email`, `token`, `date_created`) VALUES (8, 'winandrikusuma27@gmail.com', 'yK7iYglV2Zuh1s/PHt5DzhxVkf2Nfg7yOiBC45NHcZo=', 1610874251);
INSERT INTO `user_token` (`id_token`, `email`, `token`, `date_created`) VALUES (9, 'winandrikusuma27@gmail.com', 'O55rIzIrzLcKeHHaYW40/lSm9sU5Bh5F+5p713BCNtc=', 1610874295);
INSERT INTO `user_token` (`id_token`, `email`, `token`, `date_created`) VALUES (10, 'albabaihaki12@gmail.com', 'hT3X7ytC4A5DY27qo0Bg9DH70wDLUmweuJlzYOHBrWY=', 1611557711);
INSERT INTO `user_token` (`id_token`, `email`, `token`, `date_created`) VALUES (20, 'naufalyudhistira12@gmail.com', 'Dt366jdJpwtkFwhYjue9MAffPTtOR9DsBPaYa91pAsg=', 1615265944);
INSERT INTO `user_token` (`id_token`, `email`, `token`, `date_created`) VALUES (21, 'winandrikusuma27@gmail.com', 'i/ieXfkGuuX+/Wlp2GeW6QpL/icofK3L1vWOyzP+oO4=', 1615289449);
INSERT INTO `user_token` (`id_token`, `email`, `token`, `date_created`) VALUES (22, 'winandrikusuma27@gmail.com', 'qKJuLPnb1u9Z35noNFayX2Jdkgmj/Yf6BJ2RHCZXC1M=', 1615289502);
INSERT INTO `user_token` (`id_token`, `email`, `token`, `date_created`) VALUES (23, 'winandrikusuma27@gmail.com', 'VzbCu5toNr66ekwtKKLYvVICiq0LWwirY0kPeTLqrCM=', 1615289613);
INSERT INTO `user_token` (`id_token`, `email`, `token`, `date_created`) VALUES (25, 'winandrikusuma27@gmail.com', 'IEPHm6UHvqNlSKkHpkIEgx0BEiIXNMIRTfNV/M5xilc=', 1615290623);


